// App entry. ES modules. Feature toggles live in /features/config.js
import { FEATURES } from './features/config.js';

const $ = (sel, ctx=document) => ctx.querySelector(sel);
const $$ = (sel, ctx=document) => Array.from(ctx.querySelectorAll(sel));

// Init
document.addEventListener('DOMContentLoaded', async () => {
  // Footer year
  $('#year').textContent = String(new Date().getFullYear());

  // Demo button
  $('#demoButton')?.addEventListener('click', () => {
    alert('Demo ran. Replace with your business logic.');
  });

  // Load enabled features
  await loadFeatures();
});

async function loadFeatures(){
  const list = $('#featureList');
  const items = [];

  for (const [name, cfg] of Object.entries(FEATURES)){
    if (!cfg.enabled) continue;
    try {
      const mod = await import(`./${cfg.path}`);
      await mod.init(cfg.options || {});
      items.push(renderCard(name, mod.meta?.description || 'Enabled feature'));
    } catch (err){
      console.error('[Feature failed]', name, err);
      items.push(renderCard(name, 'Failed to load. See console.', true));
    }
  }
  if (list) list.replaceChildren(...items);
}

function renderCard(title, desc, error=false){
  const li = document.createElement('li');
  li.className = 'feature-card';
  li.innerHTML = `<h4>${escapeHtml(title)}${error ? ' ⚠️' : ''}</h4><p>${escapeHtml(desc)}</p>`;
  return li;
}

function escapeHtml(s){
  return String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
}
