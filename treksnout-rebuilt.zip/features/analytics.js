export const meta = { description: 'Analytics hook. Swap provider via config.' };

export async function init(opts={}){
  if (opts.provider === 'plausible'){
    const s = document.createElement('script');
    s.defer = true;
    s.dataset.domain = opts.domain || 'example.com';
    s.src = 'https://plausible.io/js/script.js';
    document.head.appendChild(s);
  }
  // Add more providers as needed.
}
