// Central feature flags. Toggle enabled: true/false. Point to a JS module in /features.
export const FEATURES = {
  darkMode: { enabled: true,  path: 'darkMode.js', options: { storageKey: 'theme' } },
  consent:  { enabled: false, path: 'consent.js',  options: { policyUrl: '/privacy' } },
  analytics:{ enabled: false, path: 'analytics.js',options: { provider: 'plausible', domain: 'example.com' } }
};
