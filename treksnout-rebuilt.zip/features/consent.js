export const meta = { description: 'Cookie consent banner with minimal UI.' };

export async function init(opts={}){
  const key = 'consent.v1';
  if (localStorage.getItem(key)) return;

  const banner = document.createElement('div');
  banner.role = 'region';
  banner.ariaLabel = 'Cookie consent';
  banner.style.position = 'fixed';
  banner.style.inset = 'auto 12px 12px 12px';
  banner.style.padding = '12px 16px';
  banner.style.background = 'color-mix(in oklab, var(--panel), white 5%)';
  banner.style.border = '1px solid #1b2a46';
  banner.style.borderRadius = '10px';
  banner.style.boxShadow = 'var(--shadow)';

  const html = `<div style="display:flex;gap:12px;align-items:center;justify-content:space-between;flex-wrap:wrap">
    <span>We use basic cookies. <a href="${opts.policyUrl || '#'}">Learn more</a>.</span>
    <div style="display:flex;gap:8px">
      <button id="consent-accept" class="btn">Accept</button>
      <button id="consent-decline" class="btn" style="background:var(--danger);color:#000">Decline</button>
    </div>
  </div>`;
  banner.innerHTML = html;
  document.body.appendChild(banner);

  banner.querySelector('#consent-accept')?.addEventListener('click', () => {
    localStorage.setItem(key, 'accepted');
    banner.remove();
  });
  banner.querySelector('#consent-decline')?.addEventListener('click', () => {
    localStorage.setItem(key, 'declined');
    banner.remove();
  });
}
