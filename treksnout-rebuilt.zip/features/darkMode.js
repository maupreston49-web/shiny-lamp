export const meta = { description: 'Dark mode toggle with prefers-color-scheme support.' };

export async function init(opts={}){
  const key = opts.storageKey || 'theme';
  const btn = document.createElement('button');
  btn.className = 'btn';
  btn.style.marginTop = '8px';
  btn.setAttribute('aria-pressed', 'false');
  btn.textContent = 'Toggle theme';

  btn.addEventListener('click', () => {
    const next = document.documentElement.dataset.theme === 'light' ? 'dark' : 'light';
    applyTheme(next);
    try { localStorage.setItem(key, next); } catch {}
    btn.setAttribute('aria-pressed', String(next === 'dark'));
  });

  // Initial
  const saved = safeGet(key);
  const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  applyTheme(saved || (prefersDark ? 'dark' : 'light'));
  btn.setAttribute('aria-pressed', String(document.documentElement.dataset.theme === 'dark'));

  // Mount
  const hero = document.querySelector('.hero');
  hero?.appendChild(btn);
}

function applyTheme(theme){
  document.documentElement.dataset.theme = theme;
  if (theme === 'light'){
    document.documentElement.style.setProperty('--bg', '#f7f9fc');
    document.documentElement.style.setProperty('--panel', '#ffffff');
    document.documentElement.style.setProperty('--text', '#0b1220');
    document.documentElement.style.setProperty('--muted', '#516070');
  } else {
    document.documentElement.style.removeProperty('--bg');
    document.documentElement.style.removeProperty('--panel');
    document.documentElement.style.removeProperty('--text');
    document.documentElement.style.removeProperty('--muted');
  }
}

function safeGet(k){ try { return localStorage.getItem(k); } catch { return null; } }
